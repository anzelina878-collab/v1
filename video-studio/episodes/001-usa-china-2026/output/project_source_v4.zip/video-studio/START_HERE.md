Полный проект v4 — настоящее видео и круговое вращение оружия.

В ZIP есть оригинальный голос, текст, ТЗ, изображения, готовые 3D-обороты и код.
81 подготовленная архивная видеовставка догружается автоматически (около 234 MiB).
Это не требует Git, аккаунта или API-ключа.

1. Распакуйте ZIP.
2. Откройте терминал в папке video-studio. Нужны Python и FFmpeg.
3. pip install -r requirements.txt
4. python tools/fetch_episode_media.py episodes/001-usa-china-2026/episode.v4.json
5. python render.py validate episodes/001-usa-china-2026/episode.v4.json
6. python render.py render-fast episodes/001-usa-china-2026/episode.v4.json --output episodes/001-usa-china-2026/output/my_render_v4.mp4 --crf 23 --preset fast

См. REVISION_FULL_V4.md и WHAT_TO_SEND_FOR_3D.md в папке выпуска.
Новый код для вращения присылать не нужно: нужны точные модели GLB/FBX/OBJ/BLEND.
