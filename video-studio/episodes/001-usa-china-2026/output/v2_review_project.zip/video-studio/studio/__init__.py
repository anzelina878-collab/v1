"""Reusable editorial video renderer."""
